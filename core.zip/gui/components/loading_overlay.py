import tkinter as tk
import math

class IntegratedLoadingOverlay:
    def __init__(self, parent_app):
        self.parent_app = parent_app
        self.overlay_frame = None
        self.animation_running = True
        self.animation_step = 0
        self.animation_id = None

        self._create_overlay()
        self.parent_app.after(1, self._start_spinner_animation)

    def _create_overlay(self):
        self.overlay_frame = tk.Frame(self.parent_app, bg="#10131a")
        self.overlay_frame.place(x=0, y=0, relwidth=1, relheight=1)

        # Neon card
        self.card_frame = tk.Frame(self.overlay_frame, bg="#161a22", bd=0, highlightthickness=0)
        self.card_frame.place(relx=0.5, rely=0.5, anchor="center", width=420, height=280)

        # Neon border
        self.neon = tk.Canvas(self.card_frame, width=400, height=260, bg="#161a22", highlightthickness=0)
        self.neon.place(x=10, y=10)
        self.neon_id = self.neon.create_rectangle(8, 8, 392, 252, outline="#00fff7", width=6)

        # Spinner
        self.spinner_canvas = tk.Canvas(self.card_frame, width=64, height=64, bg="#161a22", highlightthickness=0, bd=0)
        self.spinner_canvas.place(relx=0.11, y=38, anchor="w")

        # Logo
        self.logo_label = tk.Label(
            self.card_frame,
            text="🪄",
            bg="#161a22",
            fg="#00fff7",
            font=("Segoe UI", 44, "bold")
        )
        self.logo_label.place(relx=0.38, y=50, anchor="center")
        
        # Title
        self.title_label = tk.Label(
            self.card_frame,
            text="BENSON v2.0",
            bg="#161a22",
            fg="#fff",
            font=("Segoe UI", 21, "bold")
        )
        self.title_label.place(relx=0.5, y=110, anchor="center")

        # Subtitle
        self.subtitle_label = tk.Label(
            self.card_frame,
            text="Advanced Edition",
            bg="#161a22",
            fg="#00fff7",
            font=("Segoe UI", 12)
        )
        self.subtitle_label.place(relx=0.5, y=140, anchor="center")

        # Status label
        self.status_label = tk.Label(
            self.card_frame,
            text="Initializing...",
            bg="#161a22",
            fg="#fff",
            font=("Segoe UI", 13)
        )
        self.status_label.place(relx=0.5, y=185, anchor="center")

    def _start_spinner_animation(self):
        if not self.animation_running or not self.overlay_frame:
            return
        try:
            self.spinner_canvas.delete("all")
            angle_offset = (self.animation_step % 24) * 15
            for i in range(12):
                angle = math.radians(angle_offset + i * 30)
                x0 = 32 + 22 * math.cos(angle)
                y0 = 32 + 22 * math.sin(angle)
                x1 = 32 + 28 * math.cos(angle)
                y1 = 32 + 28 * math.sin(angle)
                self.spinner_canvas.create_line(x0, y0, x1, y1, fill="#00fff7", width=4, capstyle=tk.ROUND)

            neon_colors = ["#00fff7", "#00f3ff", "#30fff7", "#00fff7"]
            self.neon.itemconfig(self.neon_id, outline=neon_colors[self.animation_step % 4])

            if self.animation_step % 8 < 4:
                self.status_label.configure(fg="#00fff7")
            else:
                self.status_label.configure(fg="#fff")

            self.animation_step += 1
            if self.animation_running:
                self.animation_id = self.parent_app.after(60, self._start_spinner_animation)
        except tk.TclError:
            self.animation_running = False

    def update_status(self, status_text):
        if self.status_label and self.status_label.winfo_exists():
            self.status_label.configure(text=status_text)
            self.parent_app.update_idletasks()

    def close(self):
        self.animation_running = False
        if self.animation_id:
            try:
                self.parent_app.after_cancel(self.animation_id)
            except:
                pass
        if self.overlay_frame and self.overlay_frame.winfo_exists():
            self.overlay_frame.destroy()
        self.overlay_frame = None
        self.status_label = None
        self.logo_label = None
